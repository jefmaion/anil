<?php 

$config["env_app_name"] =  "GeoClinica"; 
$config["env_environment"] =  "production"; 
$config["env_db_server"] =  "127.0.0.1"; 
$config["env_db_name"] =  "exames"; 
$config["env_db_user"] =  "root"; 
$config["env_db_pass"] =  ""; 
$config["run_migration"] =  "on"; 

?>