<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
class Migrate extends CI_Controller { 
    public function index() { 

        $this->load->dbforge();
		$this->dbforge->drop_table('migrations', TRUE);

        $this->load->library('migration');
        
        if ($this->migration->current() === FALSE)
        {
            echo $this->migration->error_string();
        }else{
            return responseRedirect('/setup', 'Configurações Salvas Com Sucesso!');
        }
    }

}