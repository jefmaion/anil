<!-- General JS Scripts -->
<script src="<?= base_url('public/template/assets/js/app.min.js') ?>"></script>
    <!-- JS Libraies -->
    <!-- Page Specific JS File -->

    <script>

        if($('.alert-dismiss').length > 0) {
            $('.alert-dismiss').delay(5000).fadeOut()
        }
    </script>

    <!-- Template JS File -->
    <script src="<?= base_url('public/template/assets/js/scripts.js') ?>"></script>
    <!-- Custom JS File -->
    <script src="<?= base_url('public/template/assets/js/custom.js') ?>"></script>