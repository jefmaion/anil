<!-- General CSS Files -->
<link rel="stylesheet" href="<?= base_url('public/template/assets/css/app.min.css') ?>">

<link rel="stylesheet" href="<?= base_url('public/template/assets/bundles/datatables/datatables.min.css') ?>">
    <link rel="stylesheet" href="<?= base_url('public/template/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css') ?>">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?= base_url('public/template/assets/css/style.css') ?>">
    <link rel="stylesheet" href="<?= base_url('public/template/assets/css/components.css') ?>">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="<?= base_url('public/template/assets/css/custom.css?t=' . date('s')) ?>">
    <link rel='shortcut icon' type='image/x-icon' href='<?= base_url("public/template/assets/img/favicon.ico") ?>' />